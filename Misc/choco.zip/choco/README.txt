=============
 Chocosticks
=============

http://code.google.com/p/chocosticks

Runs natively on DOS/Windows95/98/ME/2000/XP.
Chocosticks is built using TurboC3.0 which is a 16-bit compiler.
The above systems allow 16-bit code to be executed natively.
Runs in Dosbox on winVista/win7/win8.

1. Download the archive choco.zip
2. Extract the archive at some place on your PC.
3. It will create a "choco" directory which contains:
    - GAME.exe The chocosticks binary. 
    - BGI The Borland Graphics Interface libraries. 
4. Run the executable GAME.exe and enjoy! ;-)

More info available at:
http://code.google.com/p/chocosticks